from langchain_openai import ChatOpenAI
from dotenv import load_dotenv

load_dotenv()

model = ChatOpenAI(model = 'gpt-4', temperature=0.1, max_completion_tokens=10)

result = model.invoke("What is the capital of india?")

print(result.content)

# to run this file and see the output run the below code
# python 2.ChatModels/1_chatmodel_openai.py