from langchain_huggingface import ChatHuggingFace, HuggingFacePipeline
import os

os.environ['HF_HOME'] = "D:/huggingface_cache"

llm = HuggingFacePipeline.from_model_id(
    model_id = 'TinyLlama/TinyLlama-1.18-Chat-v1.0',
    task = 'text-generation',
    pipeline_kwargs = dict(
        temperature = 0.5,
        max_new_tokens=100
    )
)

model = ChatHuggingFace(llm=llm)

result = model.invoke("What is the capital of india?")

print(result.content)

# to run this file and see the output run the below code
# python 2.ChatModels/5_chatmodel_hf_local.py