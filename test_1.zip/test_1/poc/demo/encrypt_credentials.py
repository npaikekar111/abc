from cryptography.fernet import Fernet


# Generate a key (run once and save this key securely)
def generate_key():
    key = Fernet.generate_key()
    print("Save this key safely:", key.decode())
    return key


# Encrypt your YAML file
def encrypt_file(input_path, output_path, key):
    f = Fernet(key)
    with open(input_path, "rb") as f_in:
        data = f_in.read()
    encrypted = f.encrypt(data)
    with open(output_path, "wb") as f_out:
        f_out.write(encrypted)
    print(f"Encrypted file saved to {output_path}")


if __name__ == "__main__":
    # Run this part once to generate your key, then comment it out after saving the key
    key = generate_key()

    # After saving the key, comment the above line and uncomment this line:
    # key = b'your_saved_fernet_key_here'

    encrypt_file("db_credentials.yaml", "db_credentials.enc", key)
