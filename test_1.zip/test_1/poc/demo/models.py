from django.db import models
from django.utils import timezone

class RawEvent(models.Model):
    # store raw incoming payload for debugging / reprocessing
    created_at = models.DateTimeField(auto_now_add=True)
    source = models.CharField(max_length=200, null=True, blank=True)
    payload = models.JSONField()

    class Meta:
        indexes = [
            models.Index(fields=["created_at"]),
        ]

class AggregatedEvent(models.Model):
    hour_start = models.DateTimeField()  # e.g., 2025-10-03T14:00:00 represents 14:00-15:00
    count = models.IntegerField(default=0)
    merged_payload = models.JSONField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    processed = models.BooleanField(default=False)
    # optionally store DB-fetch results
    db_results = models.JSONField(null=True, blank=True)

    class Meta:
        unique_together = ("hour_start",)
        indexes = [
            models.Index(fields=["hour_start"]),
        ]
