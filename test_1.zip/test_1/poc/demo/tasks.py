from celery import shared_task
from django.utils import timezone
from django.conf import settings
from .models import AggregatedEvent, RawEvent
import json
import datetime
import redis
from .utils.credentials import load_credentials
from .utils.db_connect import fetch_from_db

r = redis.from_url(settings.REDIS_URL)

@shared_task
def aggregate_hourly_process(use_redis=True):
    """
    This task should be scheduled to run at each hour (or run every few minutes
    and process completed hours).
    """
    now = timezone.now()
    # process previous hour (e.g., if now is 15:02, process 14:00-15:00)
    prev_hour = (now - datetime.timedelta(hours=1)).replace(minute=0, second=0, microsecond=0)
    hour_key = int(prev_hour.timestamp())
    if use_redis:
        key = f"events:{hour_key}"
        # get all items
        data = []
        while True:
            item = r.lpop(key)
            if item is None:
                break
            data.append(json.loads(item))
        if not data:
            # nothing to do
            return {"status": "no_data", "hour": prev_hour.isoformat()}
        aggregated_payload = {"events": data, "count": len(data)}
    else:
        # DB fallback: collect RawEvent in the hour
        start = prev_hour
        end = prev_hour + datetime.timedelta(hours=1)
        qs = RawEvent.objects.filter(created_at__gte=start, created_at__lt=end)
        data = list(qs.values("id", "payload", "created_at"))
        if not data:
            return {"status": "no_data", "hour": prev_hour.isoformat()}
        aggregated_payload = {"events": [d["payload"] for d in data], "count": len(data)}

    # create AggregatedEvent
    agg, created = AggregatedEvent.objects.get_or_create(
        hour_start=prev_hour,
        defaults={"count": aggregated_payload["count"], "merged_payload": aggregated_payload},
    )
    if not created:
        # update existing
        agg.count = aggregated_payload["count"]
        agg.merged_payload = aggregated_payload
        agg.save()

    # optional: fetch data from a DB using credentials — show sample using alias
    try:
        # choose alias(s) based on merged payload rules; here we demo one alias
        alias = "analytics_pg"
        db_rows = fetch_from_db(alias)
        # convert rows into JSON-safe structure
        agg.db_results = [list(r) if hasattr(r, "__iter__") else r for r in db_rows]
        agg.processed = True
        agg.save()
    except Exception as e:
        # log error; leave processed false
        agg.processed = False
        agg.db_results = {"error": str(e)}
        agg.save()

    return {"status": "ok", "hour": prev_hour.isoformat(), "count": agg.count}
