from django.contrib import admin
from .models import RawEvent, AggregatedEvent

@admin.register(RawEvent)
class RawEventAdmin(admin.ModelAdmin):
    list_display = ('id', 'created_at', 'source')
    list_filter = ('created_at', 'source')
    search_fields = ('source',)
    readonly_fields = ('created_at', 'payload')
    ordering = ('-created_at',)

@admin.register(AggregatedEvent)
class AggregatedEventAdmin(admin.ModelAdmin):
    list_display = ('id', 'hour_start', 'count', 'processed', 'created_at')
    list_filter = ('processed', 'hour_start')
    search_fields = ()
    readonly_fields = ('created_at',)
    ordering = ('-hour_start',)
