from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
import json

@csrf_exempt
def ingest(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            # Process your data here, e.g. save to RawEvent
            # RawEvent.objects.create(payload=data, source="api")
            return JsonResponse({"status": "success"})
        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid JSON"}, status=400)
    else:
        return JsonResponse({"error": "POST request required"}, status=405)
