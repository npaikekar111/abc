
# yourapp/utils/db_connect.py
import psycopg2
from psycopg2 import pool as pg_pool
import pyodbc
import threading
from django.conf import settings
from .credentials import load_credentials

# simple in-process connection pools registry
_POOLS = {}
_POOLS_LOCK = threading.Lock()

def get_pg_pool(alias, cfg):
    """
    Return a psycopg2 pool for Postgres (create if necessary).
    """
    with _POOLS_LOCK:
        if alias in _POOLS:
            return _POOLS[alias]
        minconn = cfg.get("pool_min", 1)
        maxconn = cfg.get("pool_max", 10)
        conninfo = {
            "host": cfg["host"],
            "port": cfg.get("port", 5432),
            "user": cfg["user"],
            "password": cfg["password"],
            "dbname": cfg["dbname"],
        }
        dsn = " ".join(f"{k}={v}" for k, v in conninfo.items())
        pool = pg_pool.ThreadedConnectionPool(minconn, maxconn, dsn)
        _POOLS[alias] = pool
        return pool

def get_mssql_conn(cfg):
    """
    Returns a pyodbc connection (caller must close).
    """
    driver = cfg.get("driver", "ODBC Driver 17 for SQL Server")
    host = cfg["host"]
    port = cfg.get("port", 1433)
    db = cfg.get("database")
    uid = cfg["user"]
    pwd = cfg["password"]
    conn_str = f"DRIVER={{{driver}}};SERVER={host},{port};DATABASE={db};UID={uid};PWD={pwd}"
    return pyodbc.connect(conn_str, autocommit=True)

def fetch_from_db(alias):
    """
    Generic fetch interface - reads credentials file, picks the config
    by alias, runs a fetch (example: simple SELECT 1).
    Customize as needed.
    """
    cfgs = load_credentials()
    cfg = cfgs.get(alias)
    if not cfg:
        raise KeyError(f"No DB config found for alias: {alias}")

    engine = cfg["engine"]
    if engine in ("postgresql", "postgres"):
        pool = get_pg_pool(alias, cfg)
        conn = pool.getconn()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT now()")
                return cur.fetchall()
        finally:
            pool.putconn(conn)
    elif engine in ("mssql", "sqlserver"):
        conn = get_mssql_conn(cfg)
        try:
            cur = conn.cursor()
            cur.execute("SELECT GETDATE()")  # sample
            rows = cur.fetchall()
            cur.close()
            return rows
        finally:
            conn.close()
    else:
        raise NotImplementedError(f"Engine {engine} not supported")
