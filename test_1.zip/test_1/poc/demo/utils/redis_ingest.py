# yourapp/utils/redis_ingest.py
import json
import time
import math
import redis
from django.conf import settings

r = redis.from_url(settings.REDIS_URL)

def push_event(payload, key_prefix="events"):
    now = int(time.time())
    # compute hour-key: use UTC hour boundary
    hour = now - (now % 3600)
    key = f"{key_prefix}:{hour}"
    r.rpush(key, json.dumps(payload))
    # set expiry to 2 hours to avoid stale keys
    r.expire(key, 2 * 3600)
