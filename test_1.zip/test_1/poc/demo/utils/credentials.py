import yaml
from cryptography.fernet import Fernet
from django.conf import settings
from pathlib import Path

def load_credentials():
    path = Path(settings.DB_CREDENTIALS_PATH)
    if not path.exists():
        raise FileNotFoundError(f"Credentials file not found: {path}")
    data = path.read_bytes()
    key = settings.DB_CREDENTIALS_KEY
    if key:
        f = Fernet(key.encode() if isinstance(key, str) else key)
        data = f.decrypt(data)
    creds = yaml.safe_load(data)
    return creds.get("databases", {})