import langchain

print(langchain.__version__)