from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
from typing import TypedDict, Annotated, Optional, Literal
from pydantic import BaseModel, Field

load_dotenv()

model = ChatOpenAI()

#schema
class Review(BaseModel):
    key_themes : list[str]=Field(description='write down all the key themes discussed in the review in the list')
    summary : str = Field(description='A brief summary of the review')
    sentiment: Literal['pos','neg']= Field(description='Return sentiment of the review either positive, negative or neuratl')
    pros : Optional[list[str]]= Field(default=None, description="Write down all the pros inside the list")
    cons:Optional[list[str]]= Field(default=None, description="Write down all the pros inside the list")
    cons: Annotated[Optional[list[str]], "Write down all the cons inside the list"]
    name: Optional[str] = Field(default=None, description="write the name of the reviewer")
   
structured_model = model.with_structured_output(Review)

result = model.invoke("""Great sound quality with minor quirks"

I’ve been using these headphones for about three weeks, and they’ve quickly become my go-to for work and travel.
The active noise cancellation is impressive — it blocks out the hum of the train and chatter at the office,
making it easier to focus.
Pros:
Excellent sound quality — crisp highs and solid bass without distortion
Comfortable fit — soft ear cushions, good for long listening sessions
Long battery life — I get close to 30 hours on a single charge
Strong Bluetooth connectivity — connects instantly with my phone and laptop
Cons:
Touch controls are overly sensitive — often pause music accidentally when adjusting
Slight audio delay in videos — noticeable when watching Netflix or YouTube
Bulky case — not the most portable if you travel light
Key Themes:
Productivity and travel-friendly: Ideal for remote work or commuting
User experience: While high-tech, touch controls could be more intuitive
Value vs. premium: Delivers quality close to flagship models but with minor trade-offs
Review by Daniel
""")

print(result)
print(type(result))
print(result.summary)
print(result.sentiment)