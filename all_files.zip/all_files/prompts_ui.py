from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
import streamlit as st
from langchain_core.prompts import PromptTemplate, load_prompt

load_dotenv()
model = ChatOpenAI()

st.header("Research Tool") 
# user_input =st.text_input("Enter your prompt")  #for static prompt

#dynamic prompt
paper_input = st.selectbox("select reasearch paper name", ["select ...","Attension Is All You Need", 
                "BERT: Pre-training of Deep Bidirectional Transformers", 
                "GPT-3: Language Models are Few-Shot Learners", "Diffusion models Beat GANs on Image Synthesis"])

style_input = st.selectbox("select explanation style", ["Beginner-Friendly", "Technical",
                                                        "code-Oriented", "Mathematical"])

length_input = st.selectbox("select Explanation length",["Short (1-2 paragraphs)", "Medium (3-5paragraphs)",
                                                         "Long (detailed explanation)"])

template = load_prompt('template.json')


# using chain to avoid calling invoke method every time i.e. for templates, models etc.
if st.button('Summarize'):
    chain = template | model
    result = chain.invoke({
        'paper_input':paper_input,
        'style_input':style_input,
        'length_input':length_input
})
    
    st.write(result.content)

#to run above code type streamlit run prompt_ui.py in terminal
