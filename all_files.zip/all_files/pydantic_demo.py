from pydantic import BaseModel, EmailStr, Field
from typing import Optional


class Student(BaseModel):

    name: str
    age: Optional[int] = None
    email : EmailStr
    cgpa : float = Field(gt=0, lt=10, default=5, description='A decimal value representing the cgpa of student')

new_student = {'name':'namrata','age':25,'email':'abc','cgpa':12} #try for diff. values of arguments

student = Student(**new_student)
student_dict = dict(student)

print(student_dict['age'])

print(type(student))

print(student.name)
print(student.age)
print(student)
