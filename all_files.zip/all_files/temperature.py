from langchain_openai import ChatOpenAI
from dotenv import load_dotenv

load_dotenv()

model = ChatOpenAI(model='gpt-4', temperature=0)

result = model.invoke("Write a 5 line poem on cricket")

print(result.content)

# to run above code type python temperature.py
## observe the output in the terminal by changing the values of temperature.
# the number of times you you run the code by keeping the temperature=0 you will get the same output
# once we start increasing the value of temperature we will get creative output. 
# if we want to build the application which will display same output number of times we run the code we 
# keep the temperature near to zero or zero 
# If we want to build the application where we want creative output at every runtime we will keep the 
# temperature value greater than 2.