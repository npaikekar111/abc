
# Prompt Template is used to create dynamic templates. 
# Only difference between PromptTemplate and ChatPromptTemplate is PrompttTemplate is used to create single turn message.
# While ChatPromptTemplate is used to in multi turn conversation messages. 
# To fit multiple messages in placeholders we use ChatPromptTemplate.
from langchain_core.prompts import PromptTemplate

#template
template = PromptTemplate(
    template="""
please summarize the research paper titled "{paper_input}" with the following specifications :
Explanation Style: {style_input}
explanation Length: {length_input}
1. Mathematical Details:
	 - Include relevant mathematical equations if present in the paper.
	 - Explain the mathematical concepts using simple, intuitive code snippeta wherever applicable.
2. Analogies: 
	 - use relatable analogies to simplify the complex ideas.
If certain information is not presnet in the paper, respond with "Insufficient information available"
instead of guessing.
Ensure the summary is clear, accurate and alligned with the provided style and length
""",
input_variables = ['paper_input','style_input','length_input']
)

template.save('template.json')

## to run the above code type python prompt_generator.py in command prompt terminal