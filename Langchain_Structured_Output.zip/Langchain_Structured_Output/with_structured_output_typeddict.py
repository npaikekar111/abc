from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
from typing import TypedDict, Annotated, Optional, Literal

load_dotenv()

model = ChatOpenAI()

#schema
class Review(TypedDict):

    key_themes = Annotated[list[str], "write down all the key themes discussed in the review in the list"]
    summary: Annotated[str, 'A brief summary of the review']
    sentiment: Annotated[Literal['POS', 'Neg'],'Return sentiment of the review either positive, negative or neuratl']
    pros: Annotated[Optional[list[str]], "Write down all the pros inside the list"]
    cons: Annotated[Optional[list[str]], "Write down all the cons inside the list"]
    name: Annotated[Optional[str], "write the name of the reviewer"]
   
structured_model = model.with_structured_output(Review)

result = model.invoke("""Great sound quality with minor quirks"

I’ve been using these headphones for about three weeks, and they’ve quickly become my go-to for work and travel.
The active noise cancellation is impressive — it blocks out the hum of the train and chatter at the office,
making it easier to focus.
Pros:
Excellent sound quality — crisp highs and solid bass without distortion
Comfortable fit — soft ear cushions, good for long listening sessions
Long battery life — I get close to 30 hours on a single charge
Strong Bluetooth connectivity — connects instantly with my phone and laptop
Cons:
Touch controls are overly sensitive — often pause music accidentally when adjusting
Slight audio delay in videos — noticeable when watching Netflix or YouTube
Bulky case — not the most portable if you travel light
Key Themes:
Productivity and travel-friendly: Ideal for remote work or commuting
User experience: While high-tech, touch controls could be more intuitive
Value vs. premium: Delivers quality close to flagship models but with minor trade-offs
Review by Daniel
""")

print(result)
print(type(result))
print(result['summary'])
print(result['sentiment'])