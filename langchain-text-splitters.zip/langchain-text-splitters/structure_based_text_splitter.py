from langchain.text_splitter import RecursiveCharacterTextSplitter

text = """
Think of LLMs as skyscrapers of language. Just as a skyscraper is made up of layers of floors, LLMs are built with layers of ‘transformer’ blocks. These blocks are complex algorithms that help the model pay close attention to each word and its context within a sentence.

Transformer Architecture
LLMs primarily use the Transformer architecture.
This architecture relies heavily on the self-attention mechanism, enabling the model to weigh the significance of different words in a sentence, regardless of their positional distance from each other.
Layers and Parameters
LLMs consist of multiple layers of transformers, each containing parameters that the models learn from data.
The number of layers and parameters can range from hundreds of millions to hundreds of billions.
"""

#initializing the splitter
splitter = RecursiveCharacterTextSplitter(
    chunk_size = 250, 
    chunk_overlap=0)

#perform the split
chunks = splitter.split_text(text)

print(len(chunks))
print(chunks)