from langchain.text_splitter import RecursiveCharacterTextSplitter, Language

text = """Pre-training and Fine-tuning
LLMs are pre-trained on a large corpus of text data. During this phase, they learn the language’s structure, nuances, context, and more.
After pre-training, LLMs can be fine-tuned on specific datasets to perform particular tasks like translation, question-answering, or sentiment analysis.
Attention Mechanisms
LLMs use attention mechanisms to understand the context and relationships between words in a sentence, even those far apart in the text.
Training
Training an LLM involves reading and understanding an enormous library of text. The model actively learns by predicting parts of sentences, much like filling in blanks in a puzzle.

Data Gathering
LLMs are trained on diverse and large datasets, often sourced from books, websites, and other texts, to cover a wide range of language styles and topics.
Optimization
Techniques like stochastic gradient descent are used to adjust the model’s parameters to minimize the difference between the predicted and actual outputs."""

splitter = RecursiveCharacterTextSplitter.from_language(
    language=Language.PYTHON,
    chunk_size=200,
    chunk_overlap = 0
)

chunk = splitter.split_text(text)
print(len(chunk))
print(chunk[1])