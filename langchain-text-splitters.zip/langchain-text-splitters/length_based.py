#code to split text 
from langchain.text_splitter import CharacterTextSplitter

text = """
Google’s Gemini models represent a significant advancement in artificial intelligence, offering robust capabilities
 for developers. With the release of the Gemini API, developers can now harness these models to create sophisticated 
 language applications. In this guide, we’ll explore the features of the Gemini API and walk through building a 
 beginner-level chatbot, demonstrating its practical applications and potential.
"""

splitter = CharacterTextSplitter(chunk_size=50, chunk_overlap=0, separator='')

result = splitter.split_text(text)

print(result)

## code to load doc and split the text inside doc(working of pdf loader and text splitters randomly)
# from langchain.text_splitter import CharacterTextSplitter
# from langchain_community.document_loaders import PyPDFLoader

# loader = PyPDFLoader("D:\\Namrata\\python\\studymaterial\\books\\Deep_Learning_with_Python.pdf")

# docs = loader.load()
# splitter = CharacterTextSplitter(chunk_size=200, chunk_overlap=0, separator='')

# result = splitter.split_documents(docs)

# print(result[3].page_content)

